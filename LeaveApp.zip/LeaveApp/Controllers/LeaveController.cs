﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LeaveApp.Models;

namespace LeaveApplicationNew.Controllers
{
    public class LeaveController : Controller
    {

        int leaveEligibility = 0;

        // GET: Leave
        public ActionResult Index()
        {
            leavedetailsEntities1 leavedetailsEntities = new leavedetailsEntities1();
            ViewBag.Employee = new SelectList(leavedetailsEntities.EmpMasters.ToList(), "EmpCode", "EmpName");
            return View();
        }

        public (int, int) GetTextBox(int EmpCode)
        {
            int leaveBalance = 0;
            using (leavedetailsEntities1 leavedetailsEntities = new leavedetailsEntities1())
            {
                foreach (EmpMaster emp in leavedetailsEntities?.EmpMasters)
                {
                    if (emp.EmpCode == EmpCode)
                    {
                        leaveEligibility = emp.LeaveEligibility;
                    }
                }
                leaveBalance = leaveEligibility - leavedetailsEntities.LeaveDetails.Count(balance => balance.EmpCode == EmpCode);
            }

            return (leaveBalance, leaveEligibility);
        }

        public string InsertLeave(LeaveDetail leave)
        {
            if (leave.EmpCode == 0 || leave.LeaveAppliedDate.Date.ToString("yyyy-mm-dd") == "0001-00-01")
            {
                TempData["Result"] = "Both Name and Leave Apply Date are Mandatory";
                return "Both Name and Leave Apply Date are Mandatory";

            }

            using (leavedetailsEntities1 leavedetailsEntities = new leavedetailsEntities1())
            {
                foreach (EmpMaster emp in leavedetailsEntities?.EmpMasters)
                {
                    if (emp.EmpCode == leave.EmpCode)
                    {
                        leaveEligibility = emp.LeaveEligibility;
                    }
                }

                if (leaveEligibility - leavedetailsEntities.LeaveDetails.Count(balance => balance.EmpCode == leave.EmpCode) == 0)
                {
                    TempData["Result"] = "Cannot apply leave when leave balance is zero";
                    return "Cannot apply leave when leave balance is zero";
                }

                var count = leavedetailsEntities.LeaveDetails.Where(balance => balance.EmpCode == leave.EmpCode && balance.LeaveAppliedDate == leave.LeaveAppliedDate).Count();
                if (count >= 1)
                {
                    TempData["Result"] = "Already applied leave for the same date, Please choose someother date";
                    return "Already applied leave for the same date, Please choose someother date";
                }

                leavedetailsEntities.LeaveDetails.Add(leave);
                leavedetailsEntities.SaveChanges();
            }

            TempData["Success"] = "Leave applied successfully";
            return "Leave applied successfully";
        }

    }
}